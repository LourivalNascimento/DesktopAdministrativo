﻿namespace DesktopAdministrativo
{
    partial class TelaDeLogin
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureCaixaTextCod = new System.Windows.Forms.PictureBox();
            this.pictureCerejaEsquerda = new System.Windows.Forms.PictureBox();
            this.pictureAbacaxi = new System.Windows.Forms.PictureBox();
            this.textBoxCodUser = new System.Windows.Forms.TextBox();
            this.pictureBeterraba = new System.Windows.Forms.PictureBox();
            this.pictureMorango = new System.Windows.Forms.PictureBox();
            this.textBoxSenha = new System.Windows.Forms.TextBox();
            this.pictureCerejaDireita = new System.Windows.Forms.PictureBox();
            this.labelCodUser = new System.Windows.Forms.Label();
            this.labelSenha = new System.Windows.Forms.Label();
            this.panelFundoLogin = new System.Windows.Forms.Panel();
            this.btnEntrar = new System.Windows.Forms.Button();
            this.pictureCaixaTextPassw = new System.Windows.Forms.PictureBox();
            this.pictureLogoMorangolandia = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureCenouraBottom = new System.Windows.Forms.PictureBox();
            this.pictureCenouraTop = new System.Windows.Forms.PictureBox();
            this.pictureMaca = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCaixaTextCod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCerejaEsquerda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureAbacaxi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBeterraba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMorango)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCerejaDireita)).BeginInit();
            this.panelFundoLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCaixaTextPassw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLogoMorangolandia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCenouraBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCenouraTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMaca)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureCaixaTextCod
            // 
            this.pictureCaixaTextCod.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureCaixaTextCod.BackColor = System.Drawing.Color.Transparent;
            this.pictureCaixaTextCod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCaixaTextCod.Location = new System.Drawing.Point(16, 35);
            this.pictureCaixaTextCod.Name = "pictureCaixaTextCod";
            this.pictureCaixaTextCod.Size = new System.Drawing.Size(237, 59);
            this.pictureCaixaTextCod.TabIndex = 0;
            this.pictureCaixaTextCod.TabStop = false;
            // 
            // pictureCerejaEsquerda
            // 
            this.pictureCerejaEsquerda.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pictureCerejaEsquerda.BackColor = System.Drawing.Color.Transparent;
            this.pictureCerejaEsquerda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCerejaEsquerda.Location = new System.Drawing.Point(-150, 234);
            this.pictureCerejaEsquerda.Name = "pictureCerejaEsquerda";
            this.pictureCerejaEsquerda.Size = new System.Drawing.Size(251, 213);
            this.pictureCerejaEsquerda.TabIndex = 14;
            this.pictureCerejaEsquerda.TabStop = false;
            // 
            // pictureAbacaxi
            // 
            this.pictureAbacaxi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureAbacaxi.BackColor = System.Drawing.Color.Transparent;
            this.pictureAbacaxi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureAbacaxi.Location = new System.Drawing.Point(-34, 311);
            this.pictureAbacaxi.Name = "pictureAbacaxi";
            this.pictureAbacaxi.Size = new System.Drawing.Size(447, 563);
            this.pictureAbacaxi.TabIndex = 13;
            this.pictureAbacaxi.TabStop = false;
            // 
            // textBoxCodUser
            // 
            this.textBoxCodUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(251)))), ((int)(((byte)(231)))));
            this.textBoxCodUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCodUser.Font = new System.Drawing.Font("Tw Cen MT Condensed", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCodUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(65)))), ((int)(((byte)(194)))));
            this.textBoxCodUser.Location = new System.Drawing.Point(37, 45);
            this.textBoxCodUser.Name = "textBoxCodUser";
            this.textBoxCodUser.Size = new System.Drawing.Size(196, 31);
            this.textBoxCodUser.TabIndex = 2;
            this.textBoxCodUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBeterraba
            // 
            this.pictureBeterraba.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBeterraba.BackColor = System.Drawing.Color.Transparent;
            this.pictureBeterraba.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBeterraba.Location = new System.Drawing.Point(955, 365);
            this.pictureBeterraba.Name = "pictureBeterraba";
            this.pictureBeterraba.Size = new System.Drawing.Size(433, 433);
            this.pictureBeterraba.TabIndex = 16;
            this.pictureBeterraba.TabStop = false;
            // 
            // pictureMorango
            // 
            this.pictureMorango.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureMorango.BackColor = System.Drawing.Color.Transparent;
            this.pictureMorango.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureMorango.Location = new System.Drawing.Point(909, -104);
            this.pictureMorango.Name = "pictureMorango";
            this.pictureMorango.Size = new System.Drawing.Size(433, 488);
            this.pictureMorango.TabIndex = 17;
            this.pictureMorango.TabStop = false;
            // 
            // textBoxSenha
            // 
            this.textBoxSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(251)))), ((int)(((byte)(231)))));
            this.textBoxSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSenha.Font = new System.Drawing.Font("Tw Cen MT Condensed", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(65)))), ((int)(((byte)(194)))));
            this.textBoxSenha.Location = new System.Drawing.Point(37, 140);
            this.textBoxSenha.Name = "textBoxSenha";
            this.textBoxSenha.Size = new System.Drawing.Size(196, 31);
            this.textBoxSenha.TabIndex = 3;
            this.textBoxSenha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSenha.UseSystemPasswordChar = true;
            // 
            // pictureCerejaDireita
            // 
            this.pictureCerejaDireita.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureCerejaDireita.BackColor = System.Drawing.Color.Transparent;
            this.pictureCerejaDireita.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCerejaDireita.Location = new System.Drawing.Point(1266, 234);
            this.pictureCerejaDireita.Name = "pictureCerejaDireita";
            this.pictureCerejaDireita.Size = new System.Drawing.Size(251, 213);
            this.pictureCerejaDireita.TabIndex = 19;
            this.pictureCerejaDireita.TabStop = false;
            // 
            // labelCodUser
            // 
            this.labelCodUser.AutoSize = true;
            this.labelCodUser.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCodUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.labelCodUser.Location = new System.Drawing.Point(102, 13);
            this.labelCodUser.Name = "labelCodUser";
            this.labelCodUser.Size = new System.Drawing.Size(68, 22);
            this.labelCodUser.TabIndex = 17;
            this.labelCodUser.Text = "código:";
            // 
            // labelSenha
            // 
            this.labelSenha.AutoSize = true;
            this.labelSenha.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.labelSenha.Location = new System.Drawing.Point(105, 101);
            this.labelSenha.Name = "labelSenha";
            this.labelSenha.Size = new System.Drawing.Size(62, 22);
            this.labelSenha.TabIndex = 18;
            this.labelSenha.Text = "senha:";
            // 
            // panelFundoLogin
            // 
            this.panelFundoLogin.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panelFundoLogin.BackColor = System.Drawing.Color.Transparent;
            this.panelFundoLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelFundoLogin.Controls.Add(this.btnEntrar);
            this.panelFundoLogin.Controls.Add(this.labelCodUser);
            this.panelFundoLogin.Controls.Add(this.labelSenha);
            this.panelFundoLogin.Controls.Add(this.textBoxSenha);
            this.panelFundoLogin.Controls.Add(this.textBoxCodUser);
            this.panelFundoLogin.Controls.Add(this.pictureCaixaTextPassw);
            this.panelFundoLogin.Controls.Add(this.pictureCaixaTextCod);
            this.panelFundoLogin.Location = new System.Drawing.Point(530, 385);
            this.panelFundoLogin.Name = "panelFundoLogin";
            this.panelFundoLogin.Size = new System.Drawing.Size(270, 279);
            this.panelFundoLogin.TabIndex = 22;
            // 
            // btnEntrar
            // 
            this.btnEntrar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEntrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEntrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEntrar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnEntrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEntrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrar.ForeColor = System.Drawing.Color.Black;
            this.btnEntrar.Location = new System.Drawing.Point(68, 200);
            this.btnEntrar.Name = "btnEntrar";
            this.btnEntrar.Size = new System.Drawing.Size(143, 60);
            this.btnEntrar.TabIndex = 19;
            this.btnEntrar.Text = "E N T R A R";
            this.btnEntrar.UseVisualStyleBackColor = true;
            this.btnEntrar.Click += new System.EventHandler(this.btnEntrar_Click);
            // 
            // pictureCaixaTextPassw
            // 
            this.pictureCaixaTextPassw.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureCaixaTextPassw.BackColor = System.Drawing.Color.Transparent;
            this.pictureCaixaTextPassw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCaixaTextPassw.Location = new System.Drawing.Point(16, 124);
            this.pictureCaixaTextPassw.Name = "pictureCaixaTextPassw";
            this.pictureCaixaTextPassw.Size = new System.Drawing.Size(237, 59);
            this.pictureCaixaTextPassw.TabIndex = 1;
            this.pictureCaixaTextPassw.TabStop = false;
            // 
            // pictureLogoMorangolandia
            // 
            this.pictureLogoMorangolandia.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureLogoMorangolandia.BackColor = System.Drawing.Color.Transparent;
            this.pictureLogoMorangolandia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureLogoMorangolandia.Location = new System.Drawing.Point(477, 133);
            this.pictureLogoMorangolandia.Name = "pictureLogoMorangolandia";
            this.pictureLogoMorangolandia.Size = new System.Drawing.Size(381, 207);
            this.pictureLogoMorangolandia.TabIndex = 20;
            this.pictureLogoMorangolandia.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tw Cen MT Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(606, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 44);
            this.label1.TabIndex = 21;
            this.label1.Text = "Olá, Atendente!\r\n Faça seu login!\r\n";
            // 
            // pictureCenouraBottom
            // 
            this.pictureCenouraBottom.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pictureCenouraBottom.BackColor = System.Drawing.Color.Transparent;
            this.pictureCenouraBottom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCenouraBottom.Location = new System.Drawing.Point(506, 621);
            this.pictureCenouraBottom.Name = "pictureCenouraBottom";
            this.pictureCenouraBottom.Size = new System.Drawing.Size(432, 226);
            this.pictureCenouraBottom.TabIndex = 15;
            this.pictureCenouraBottom.TabStop = false;
            // 
            // pictureCenouraTop
            // 
            this.pictureCenouraTop.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureCenouraTop.BackColor = System.Drawing.Color.Transparent;
            this.pictureCenouraTop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCenouraTop.Location = new System.Drawing.Point(526, -92);
            this.pictureCenouraTop.Name = "pictureCenouraTop";
            this.pictureCenouraTop.Size = new System.Drawing.Size(445, 257);
            this.pictureCenouraTop.TabIndex = 18;
            this.pictureCenouraTop.TabStop = false;
            // 
            // pictureMaca
            // 
            this.pictureMaca.BackColor = System.Drawing.Color.Transparent;
            this.pictureMaca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureMaca.Location = new System.Drawing.Point(-62, -129);
            this.pictureMaca.Name = "pictureMaca";
            this.pictureMaca.Size = new System.Drawing.Size(501, 488);
            this.pictureMaca.TabIndex = 12;
            this.pictureMaca.TabStop = false;
            // 
            // TelaDeLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(139)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1366, 745);
            this.Controls.Add(this.pictureCerejaEsquerda);
            this.Controls.Add(this.pictureAbacaxi);
            this.Controls.Add(this.pictureBeterraba);
            this.Controls.Add(this.pictureMorango);
            this.Controls.Add(this.pictureCerejaDireita);
            this.Controls.Add(this.panelFundoLogin);
            this.Controls.Add(this.pictureLogoMorangolandia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureCenouraBottom);
            this.Controls.Add(this.pictureCenouraTop);
            this.Controls.Add(this.pictureMaca);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(139)))), ((int)(((byte)(248)))));
            this.Name = "TelaDeLogin";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureCaixaTextCod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCerejaEsquerda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureAbacaxi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBeterraba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMorango)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCerejaDireita)).EndInit();
            this.panelFundoLogin.ResumeLayout(false);
            this.panelFundoLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCaixaTextPassw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLogoMorangolandia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCenouraBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCenouraTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMaca)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureCaixaTextCod;
        private System.Windows.Forms.PictureBox pictureCerejaEsquerda;
        private System.Windows.Forms.PictureBox pictureAbacaxi;
        private System.Windows.Forms.TextBox textBoxCodUser;
        private System.Windows.Forms.PictureBox pictureBeterraba;
        private System.Windows.Forms.PictureBox pictureMorango;
        private System.Windows.Forms.TextBox textBoxSenha;
        private System.Windows.Forms.PictureBox pictureCerejaDireita;
        private System.Windows.Forms.Label labelCodUser;
        private System.Windows.Forms.Label labelSenha;
        private System.Windows.Forms.Panel panelFundoLogin;
        private System.Windows.Forms.Button btnEntrar;
        private System.Windows.Forms.PictureBox pictureCaixaTextPassw;
        private System.Windows.Forms.PictureBox pictureLogoMorangolandia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureCenouraBottom;
        private System.Windows.Forms.PictureBox pictureCenouraTop;
        private System.Windows.Forms.PictureBox pictureMaca;
    }
}

